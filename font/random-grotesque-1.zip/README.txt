"Random Grotesque" is a multifunctional grotesque sans-serif typeface. It was originally designed to capture the feel of Helvetica but still maintain its unique personality. The most distinguishable feature is the inktrap. "Random Grotesque" is great for posters, logos, headings, titles, subtitles, or text blocks of different sizes.
The whole family consists of 36 styles, with 3 widths: Slim, Standard, and Spacious; 6 weights ranging from Light to Black; Upright and Italic. 12 Standard-width fonts will be free for personal and commercial uses. Each font contains 737 glyphs and supports over 101 languages.

If you want to donate, please send it to my Paypal account through the following link: https://paypal.me/randommaerks

Thank you for the support!